// home.js
console.log("Dashboard do Gestor (home.js) carregado.");

const gridItems = document.querySelectorAll('.management-grid .grid-item');

gridItems.forEach(item => {
    item.addEventListener('click', () => {
        // Remove seleção de todos
        gridItems.forEach(i => i.classList.remove('selected'));
        // Adiciona seleção ao clicado
        item.classList.add('selected');
    });
});