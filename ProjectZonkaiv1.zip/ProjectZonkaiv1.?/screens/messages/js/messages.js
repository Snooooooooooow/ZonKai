// screens/messages/js/messages.js
// Esta função será chamada pelo script.js principal
function initializeMessages() {
    const contentArea = document.getElementById('main-content');
    // 1. Tenta encontrar o botão para abrir o chat da Lumie (na lista de chats)
    const lumieChatButton = document.getElementById('chat-lumie');
    if (lumieChatButton) {
        lumieChatButton.addEventListener('click', (e) => {
            e.preventDefault();
            // Ao clicar na Lumie, carrega a tela de conversa
            loadConversation();
        });
    }
    // 2. Tenta encontrar o botão de voltar (na tela de conversa)
    const backButton = document.getElementById('back-to-chat-list');
    if (backButton) {
        backButton.addEventListener('click', (e) => {
            e.preventDefault();
            // Ao clicar em voltar, carrega a lista de chats
            loadChatList();
        });
    }
    // Função para carregar a lista de chats
    async function loadChatList() {
        try {
            // Usa o fetch para buscar o HTML parcial da lista
            const response = await fetch('screens/messages/chatlist.html');
            if (!response.ok) throw new Error('Falha ao carregar lista de chats.');
            const html = await response.text();
            contentArea.innerHTML = html;
            // Re-inicializa os listeners da página recém-carregada
            initializeMessages();
        } catch (error) {
            console.error(error);
            contentArea.innerHTML = "<p>Erro ao carregar mensagens.</p>";
        }
    }
    // Função para carregar a conversa
    async function loadConversation() {
        try {
            // Usa o fetch para buscar o HTML parcial da conversa
            const response = await fetch('screens/messages/chatconversation.html');
            if (!response.ok) throw new Error('Falha ao carregar conversa.');
            const html = await response.text();
            contentArea.innerHTML = html;
            // Re-inicializa os listeners da página recém-carregada (para o botão 'voltar')
            initializeMessages();
        } catch (error) {
            console.error(error);
            contentArea.innerHTML = "<p>Erro ao carregar conversa.</p>";
        }
    }
}
// Inicia os listeners pela primeira vez
initializeMessages();