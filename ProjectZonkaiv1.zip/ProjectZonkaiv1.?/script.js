document.addEventListener("DOMContentLoaded", () => {

    // === Seletores ===
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.overlay');
    const profileBtn = document.getElementById('profile-btn');
    const themeToggle = document.getElementById('theme-toggle');
    const contentArea = document.getElementById('main-content');

    // Seletores de Modais
    const profileModal = document.getElementById('profile-modal');
    const loginModal = document.getElementById('login-modal');
    const registerModal = document.getElementById('register-modal');

    // Links de Navegação de Modais
    const goToRegisterLink = document.getElementById('go-to-register');
    const goToLoginLink = document.getElementById('go-to-login');

    // Formulários "Fake"
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const logoutBtn = document.getElementById('logout-btn');

    // Salva o conteúdo original do dashboard
    const originalContent = contentArea.innerHTML;

    // === NOVOS SELETORES (Para UI e Navegação) ===
    const modalUsernameGreet = document.getElementById('modal-username-greet');
    const regUsernameInput = document.getElementById('reg-username');
    const usernameValidationMsg = document.getElementById('username-validation-msg');
    const tipoContaSelect = document.getElementById('tipo-conta');
    const gestorFields = document.getElementById('gestor-fields');

    // IDs dos Links da Sidebar
    const sidebarDashboard = document.getElementById('sidebar-dashboard');
    const sidebarReports = document.getElementById('sidebar-reports');
    const sidebarTeam = document.getElementById('sidebar-team');
    const sidebarProjects = document.getElementById('sidebar-projects');
    const sidebarMessages = document.getElementById('sidebar-messages');

    // === Estado da Aplicação (Fake) ===
    let isLoggedIn = false;

    // === Funções ===
    function closeAllModals() {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
        profileModal.classList.remove('active');
        loginModal.classList.remove('active');
        registerModal.classList.remove('active');
    }

    function toggleSidebar() {
        if (!sidebar.classList.contains('active')) { closeAllModals(); }
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    function handleProfileClick() {
    if (!profileModal.classList.contains('active') && !loginModal.classList.contains('active')) {
        closeAllModals();
    }
    
    if (isLoggedIn) {
        profileModal.classList.toggle('active');
    } else {
        loginModal.classList.toggle('active');
    }
    
    overlay.classList.toggle('active');
    }

    function toggleTheme() {
        const currentTheme = document.body.dataset.theme;
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.body.dataset.theme = newTheme;
        localStorage.setItem('theme', newTheme);

        const icon = themeToggle.querySelector('.material-symbols-outlined');
        icon.textContent = newTheme === 'dark' ? 'light_mode' : 'dark_mode';
    }

    function checkSavedTheme() {
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.body.dataset.theme = savedTheme;

        const icon = themeToggle.querySelector('.material-symbols-outlined');
        icon.textContent = savedTheme === 'dark' ? 'light_mode' : 'dark_mode';
    }

    // TORNANDO GLOBAL
    window.loadMainContent = async function (htmlPath, scriptPath = null, viewData = {}) {
        try {
            const response = await fetch(htmlPath);

            if (!response.ok) {
                contentArea.innerHTML = `
                    <div style="padding: 20px; background-color: var(--surface-color); border-radius: var(--radius-large); margin: 20px;">
                        <h2 style="color: #ff6b6b;">ERRO DE CARREGAMENTO (404)</h2>
                        <p>O arquivo de tela não foi encontrado.</p>
                        <p>Verifique se o caminho <strong>${htmlPath}</strong> está correto.</p>
                    </div>
                `;
                throw new Error(`Falha ao carregar ${htmlPath}. Status: ${response.status}`);
            }

            let html = await response.text();
            contentArea.innerHTML = html;

            if (viewData.username) {
                const homeUsernameGreet = contentArea.querySelector('.user-details h3');
                if (homeUsernameGreet) {
                    homeUsernameGreet.textContent = `Olá, ${viewData.username}!`;
                }
            }

            if (scriptPath) {
                loadScript(scriptPath);
            }
        } catch (error) {
            console.error('Erro geral ao tentar carregar conteúdo:', error);
        }
    }

    function loadScript(scriptSrc) {
        let oldScript = document.querySelector(`script[src^="${scriptSrc.split('?')[0]}"]`);
        if (oldScript) {
            oldScript.remove();
            console.log(`Script antigo removido: ${scriptSrc}`);
        }

        const script = document.createElement('script');
        script.src = scriptSrc + `?v=${new Date().getTime()}`;
        script.defer = true;
        document.body.appendChild(script);
        console.log(`Novo script carregado: ${scriptSrc}`);
    }

    function loadPlaceholder(title) {
        contentArea.innerHTML = `
            <div style="padding: 20px; text-align: center;">
                <h2 style="color: var(--highlight-color);">${title}</h2>
                <p>Este módulo está em desenvolvimento.</p>
                <span class="material-symbols-outlined" style="font-size: 80px; margin-top: 20px;">construction</span>
            </div>
        `;
        closeAllModals();
    }

    // === Estado e Validação ===
    function setLoginState(username) {
        isLoggedIn = true;
        localStorage.setItem('username', username);
        modalUsernameGreet.textContent = `Olá, ${username}!`;
        profileBtn.querySelector('.material-symbols-outlined').textContent = 'account_circle';
        closeAllModals();
    }

    function validateUsername() {
        const username = regUsernameInput.value;
        let isValid = true;

        if (username.length <= 4) {
            usernameValidationMsg.textContent = 'Deve ter mais de 4 caracteres.';
            isValid = false;
        } else if (/[.,]/.test(username)) {
            usernameValidationMsg.textContent = 'Não pode conter pontos ou vírgulas.';
            isValid = false;
        } else {
            usernameValidationMsg.textContent = '';
        }

        if (isValid) {
            regUsernameInput.classList.remove('invalid');
            usernameValidationMsg.style.display = 'none';
        } else {
            regUsernameInput.classList.add('invalid');
            usernameValidationMsg.style.display = 'block';
        }
        return isValid;
    }

    // === Event Listeners ===
    checkSavedTheme();

    if (regUsernameInput) regUsernameInput.addEventListener('input', validateUsername);
    if (tipoContaSelect) {
        tipoContaSelect.addEventListener('change', (e) => {
            gestorFields.classList.toggle('active', e.target.value === 'gestor');
        });
    }

    menuToggle.addEventListener('click', (e) => { e.stopPropagation(); toggleSidebar(); });
    profileBtn.addEventListener('click', (e) => { e.stopPropagation(); handleProfileClick(); });
    themeToggle.addEventListener('click', toggleTheme);
    overlay.addEventListener('click', closeAllModals);

    goToRegisterLink.addEventListener('click', (e) => { e.preventDefault(); loginModal.classList.remove('active'); registerModal.classList.add('active'); });
    goToLoginLink.addEventListener('click', (e) => { e.preventDefault(); registerModal.classList.remove('active'); loginModal.classList.add('active'); });

    if (sidebarDashboard) {
        sidebarDashboard.addEventListener('click', (e) => {
            e.preventDefault();
            const username = localStorage.getItem('username');
            window.loadMainContent('screens/companies/home.html', null, { username: username });
            closeAllModals();
        });
    }

    if (sidebarReports) {
        sidebarReports.addEventListener('click', (e) => {
            e.preventDefault();
            loadPlaceholder('Relatórios');
        });
    }

    if (sidebarTeam) {
        sidebarTeam.addEventListener('click', (e) => {
            e.preventDefault();
            loadPlaceholder('Equipe');
        });
    }

    if (sidebarProjects) {
        sidebarProjects.addEventListener('click', (e) => {
            e.preventDefault();
            loadPlaceholder('Projetos');
        });
    }

    if (sidebarMessages) {
        sidebarMessages.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('CLIQUE: Carregando módulo Mensagens...');
            window.loadMainContent('screens/messages/chatlist.html', 'screens/messages/js/messages.js');
            closeAllModals();
        });
    } else {
        console.error("ERRO: Link de Mensagens (#sidebar-messages) não encontrado no DOM.");
    }

    // === Login/Logout ===
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('login-username').value;
        setLoginState(username);
        window.loadMainContent('screens/companies/home.html', null, { username: username });
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!validateUsername()) return;

        const username = regUsernameInput.value;
        const userType = tipoContaSelect.value;

        setLoginState(username);

        if (userType === 'gestor') {
            window.loadMainContent('screens/companies/home.html', null, { username: username });
        } else {
            contentArea.innerHTML = `<div style="padding: 20px;"><h2>Dashboard (Trabalhador)</h2><p>Bem-vindo, ${username}!</p></div>`;
        }
    });

    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn = false;
        localStorage.removeItem('username');
        closeAllModals();

        profileBtn.querySelector('.material-symbols-outlined').textContent = 'person';
        modalUsernameGreet.textContent = 'Olá, Usuário!';

        contentArea.innerHTML = originalContent;
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeAllModals();
    });

    // === VERIFICAÇÃO INICIAL ===
    const savedUsername = localStorage.getItem('username');
    if (savedUsername) {
        setLoginState(savedUsername);
        window.loadMainContent('screens/companies/home.html', null, { username: savedUsername });
    }
});

document.addEventListener("DOMContentLoaded", () => {
    // Função para garantir que o botão funcione mesmo se for criado depois
    function setupGoToProfileButton() {
        const goToProfileBtn = document.getElementById('go-to-profile');

        if (goToProfileBtn) {
            goToProfileBtn.addEventListener('click', (e) => {
                e.preventDefault();

                const username = localStorage.getItem('username') || 'Usuário';
                console.log('➡️ Clicou em Ver perfil completo:', username);

                // Fecha o modal antes de trocar o conteúdo
                if (typeof closeAllModals === 'function') {
                    closeAllModals();
                } else {
                    console.warn('⚠️ Função closeAllModals() não encontrada.');
                }

                // Carrega a tela de perfil
                if (typeof window.loadMainContent === 'function') {
                    window.loadMainContent(
                        'accounts/profile.html',
                        'screens/profile/js/profile.js',
                        { username: username }
                    );
                } else {
                    console.error('❌ Função window.loadMainContent() não encontrada.');
                }
            });

            console.log("✅ Botão 'Ver perfil completo' configurado com sucesso.");
        } else {
            console.warn("⚠️ Botão 'go-to-profile' ainda não está no DOM.");
        }
    }

    // Tenta configurar imediatamente
    setupGoToProfileButton();

    // Observa o DOM (útil se o modal for injetado dinamicamente)
    const observer = new MutationObserver(() => {
        if (document.getElementById('go-to-profile')) {
            setupGoToProfileButton();
            observer.disconnect(); // Para de observar depois de achar o botão
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
});

// Cria partículas neon flutuantes
document.addEventListener("DOMContentLoaded", () => {
    const bgContainer = document.querySelector('.background-animation');
    const particleCount = 80;
    const particles = [];

    for (let i = 0; i < particleCount; i++) {
        const span = document.createElement('span');
        span.style.left = Math.random() * 100 + 'vw';
        span.style.top = Math.random() * 100 + 'vh';
        span.style.width = span.style.height = (Math.random() * 3 + 1) + 'px';
        span.dataset.speed = (Math.random() * 0.5 + 0.1).toFixed(2);
        bgContainer.appendChild(span);
        particles.push(span);
    }

    function animateParticles() {
        particles.forEach(p => {
            let top = parseFloat(p.style.top);
            let speed = parseFloat(p.dataset.speed);
            top -= speed;
            if (top < -5) top = 100;
            p.style.top = top + 'vh';
        });
        requestAnimationFrame(animateParticles);
    }

    animateParticles();
});